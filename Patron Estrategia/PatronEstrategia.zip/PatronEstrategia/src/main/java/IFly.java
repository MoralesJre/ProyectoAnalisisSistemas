public interface IFly {
    public void fly();
}
