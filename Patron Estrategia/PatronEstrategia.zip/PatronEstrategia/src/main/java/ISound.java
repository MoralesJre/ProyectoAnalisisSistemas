public interface ISound {
    public void makeSound();
}
